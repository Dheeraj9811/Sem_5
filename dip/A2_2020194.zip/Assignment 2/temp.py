# Bell (B-spline Order 2) interpolation
